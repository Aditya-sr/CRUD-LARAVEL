<?php

namespace App\Http\Controllers;
use App\Models\UserData;
use Illuminate\Http\Request;

class UserController extends Controller
{       
    public function index()
    {
        return view('form');

    }


    
    public function store(Request $request)
    {
        // Validate the request data
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:20',
            'email' => 'required|email|unique:user_data|max:255',
            'dob' => 'required|date',
        ]);

        $userData = new UserData;

        $userData->fill($validatedData);

        $userData->save();

        return redirect()->route('home')->with('success', 'Data has been stored successfully!');
    }

    public function ViewTable()
    {
        $userData = UserData::all();
    
        return view('data-table', compact('userData'));
    }


    public function delete(Request $request, $id)
    {
        $user = UserData::findOrFail($id);
        $user->delete();

        return redirect()->route('data-table')->with('success', 'User has been deleted successfully!');
    }


    public function update(Request $request, $id)
{
    $validatedData = $request->validate([
        'name' => 'required|string|max:255',
        'phone' => 'required|string|max:20',
        'email' => 'required|email|max:255|unique:user_data,email,' . $id,
        'dob' => 'required|date',
    ]);

    $userData = UserData::findOrFail($id);

    $userData->update($validatedData);

    return redirect()->route('data-table')->with('success', 'User has been updated successfully!');
}



public function edit($id)
{
    $userData = UserData::findOrFail($id);
    return view('edit-form', compact('userData'));
}

    
}
